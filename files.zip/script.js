// script.js - minimal weather dashboard using Nominatim + Open-Meteo + Chart.js
const searchForm = document.getElementById('searchForm');
const searchInput = document.getElementById('searchInput');
const locBtn = document.getElementById('locBtn');

const placeEl = document.getElementById('place');
const tempEl = document.getElementById('temp');
const descEl = document.getElementById('desc');
const windEl = document.getElementById('wind');
const timeEl = document.getElementById('time');

const hourlyCtx = document.getElementById('hourlyChart').getContext('2d');
const dailyCtx = document.getElementById('dailyChart').getContext('2d');

let hourlyChart = null;
let dailyChart = null;

const weatherCodeMap = {
  0: "Clear sky",
  1: "Mainly clear",
  2: "Partly cloudy",
  3: "Overcast",
  45: "Fog",
  48: "Depositing rime fog",
  51: "Light drizzle",
  53: "Moderate drizzle",
  55: "Dense drizzle",
  56: "Light freezing drizzle",
  57: "Dense freezing drizzle",
  61: "Slight rain",
  63: "Moderate rain",
  65: "Heavy rain",
  66: "Light freezing rain",
  67: "Heavy freezing rain",
  71: "Slight snow fall",
  73: "Moderate snow fall",
  75: "Heavy snow fall",
  77: "Snow grains",
  80: "Slight rain showers",
  81: "Moderate rain showers",
  82: "Violent rain showers",
  85: "Slight snow showers",
  86: "Heavy snow showers",
  95: "Thunderstorm",
  96: "Thunderstorm with slight hail",
  99: "Thunderstorm with heavy hail"
};

async function geocode(query){
  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`;
  const res = await fetch(url, {headers:{'Accept':'application/json'}});
  const data = await res.json();
  if(!data || data.length === 0) throw new Error('位置未找到');
  return {lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon), display_name: data[0].display_name};
}

async function fetchWeather(lat, lon){
  // Request current + hourly + daily, timezone auto
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&hourly=temperature_2m,apparent_temperature,relativehumidity_2m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&current_weather=true&timezone=auto`;
  const res = await fetch(url);
  return await res.json();
}

function formatTime(iso){
  const d = new Date(iso);
  return d.toLocaleString();
}

function updateUI(placeName, lat, lon, weather){
  // current
  const cw = weather.current_weather;
  placeEl.textContent = `${placeName} (${lat.toFixed(3)}, ${lon.toFixed(3)})`;
  tempEl.textContent = `${cw.temperature.toFixed(1)} °C`;
  descEl.textContent = weatherCodeMap[cw.weathercode] || `Code ${cw.weathercode}`;
  windEl.textContent = `${cw.windspeed} m/s`;
  timeEl.textContent = `Observed: ${formatTime(cw.time)}`;

  // hourly chart (next 24 hours)
  const hourly = weather.hourly;
  const labels24 = [];
  const temps24 = [];
  const nowIndex = hourly.time.findIndex(t => new Date(t) >= new Date(cw.time));
  const start = Math.max(0, nowIndex);
  const end = Math.min(hourly.time.length, start + 24);
  for(let i = start; i < end; i++){
    labels24.push(new Date(hourly.time[i]).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}));
    temps24.push(hourly.temperature_2m[i]);
  }
  if(hourlyChart) hourlyChart.destroy();
  hourlyChart = new Chart(hourlyCtx, {
    type:'line',
    data:{
      labels:labels24,
      datasets:[{
        label:'Temp (°C)',
        data:temps24,
        borderColor:'#3b82f6',
        backgroundColor:'rgba(59,130,246,0.15)',
        tension:0.25,
        fill:true,
        pointRadius:2
      }]
    },
    options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:false}}}
  });

  // daily chart
  const daily = weather.daily;
  const days = daily.time.map(t => new Date(t).toLocaleDateString());
  const min = daily.temperature_2m_min;
  const max = daily.temperature_2m_max;
  if(dailyChart) dailyChart.destroy();
  dailyChart = new Chart(dailyCtx, {
    type:'bar',
    data:{
      labels:days,
      datasets:[
        {label:'Min °C', data:min, backgroundColor:'rgba(59,130,246,0.25)'},
        {label:'Max °C', data:max, backgroundColor:'rgba(234,88,12,0.25)'}
      ]
    },
    options:{scales:{y:{beginAtZero:false}}}
  });
}

async function searchAndShow(query){
  try{
    placeEl.textContent = 'Loading...';
    const loc = await geocode(query);
    const weather = await fetchWeather(loc.lat, loc.lon);
    updateUI(loc.display_name, loc.lat, loc.lon, weather);
  }catch(err){
    placeEl.textContent = 'Error: ' + err.message;
    tempEl.textContent = '— °C';
    descEl.textContent = '';
    windEl.textContent = '—';
    timeEl.textContent = '—';
  }
}

searchForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const q = searchInput.value.trim();
  if(!q) return;
  await searchAndShow(q);
});

locBtn.addEventListener('click', async ()=>{
  if(!navigator.geolocation) { alert('浏览器不支持定位'); return; }
  placeEl.textContent = 'Locating...';
  navigator.geolocation.getCurrentPosition(async pos=>{
    const lat = pos.coords.latitude;
    const lon = pos.coords.longitude;
    try{
      const reverseUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;
      const r = await fetch(reverseUrl);
      const data = await r.json();
      const display = data.display_name || `${lat.toFixed(3)}, ${lon.toFixed(3)}`;
      const weather = await fetchWeather(lat, lon);
      updateUI(display, lat, lon, weather);
    }catch(err){
      placeEl.textContent = '定位/获取天气失败';
    }
  }, err=>{
    placeEl.textContent = '定位失败: ' + err.message;
  });
});

// initial: sample city
searchInput.value = 'New York';
searchAndShow('New York');